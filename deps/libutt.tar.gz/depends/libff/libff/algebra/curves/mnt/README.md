# Implementation of the MNT4/6 cycle

## Run the sage script to generate the curve parameters

1. Make sure that you have [SageMath](https://www.sagemath.org/) installed

2. Run:
```bash
sage mnt.sage
```
