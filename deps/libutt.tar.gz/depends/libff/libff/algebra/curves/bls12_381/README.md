# Implementation of BLS12-381

## Run the sage script to generate the curve parameters

1. Make sure that you have [SageMath](https://www.sagemath.org/) installed

2. Run:
```bash
sage bls12_381.sage
```
