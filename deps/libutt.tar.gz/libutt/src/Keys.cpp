#include <utt/Configuration.h>

#include <optional>
#include <sstream>

#include <utt/Params.h>
#include <utt/Keys.h>
#include <utt/Coin.h>
#include <utt/Utt.h>
#include <utt/internal/plusaes.h>

#include <libfqfft/polynomial_arithmetic/basic_operations.hpp>

#include <xutils/NotImplementedException.h>

namespace libutt {

    LTPK::LTPK(const Params&p, const LTSK& ltsk) 
        : gr1(ltsk.s * p.pedLtskBase1()), 
          gr2(ltsk.s * p.pedLtskBase2()), 
          pok(ltsk.s * p.pokEskBase2()),
          e(ltsk.e * p.encBase())
    {
    }

    // WARNING: Need to access ESK::s, so cannot have this in header file.
    EPK::EPK(const Params& p, const ESK& esk)
        : EPK(p, esk.s) 
    {}
        
    std::string EPK::toString() const {
        std::stringstream ss;

        ss << asG1();

        return ss.str();
    }
        
    bool EpkProof::verify(const Params& p, const EPK& epk) {
        return ReducedPairing(epk.asG1(), p.pokEskBase2()) == ReducedPairing(p.pedEskBase1(), epk.pok);
    }

    ESK LTSK::deriveESK(const Params& p, const G1& R) const {
        (void)p;
        // FIXME(Crypto): implement viewing keys (same performance)
        Fr z = hashToField(s * R);

        ESK esk(s+z);
        // esk.s = s + z;
        return esk;
    }

    EPK LTPK::deriveEPK(const Params& p, const Fr& r, bool withG2) const {
        // FIXME(Crypto): implement viewing keys (same performance)
        Fr z = hashToField(r * gr1);

        return EPK(p, *this, z, withG2);
    }

    KeyPrivateCtxt LTPK::encrypt(const Params& p, const Fr& coinValue, const Fr& pedRand) const {
        (void)p;

        // Diffie-Hellman key exchange, just like in ElGamal
        Fr r = Fr::random_element();
        AutoBuf<unsigned char> enc_key = KeyPrivateCtxt::dhKex(e, r);

        // assemble AES plaintext
        size_t frSize = Fr_num_bytes();
        size_t ptxt_size = frSize * 2;
        unsigned char plaintext[ptxt_size];

        Fr_serialize(coinValue, plaintext, frSize);
        Fr_serialize(pedRand, plaintext + frSize, frSize);
        
        logdbg << "Plaintext size in bytes: " << ptxt_size << endl;

        // figure out AES ciphertext size
        size_t ctxt_size = plusaes::get_padded_encrypted_size(ptxt_size);
        KeyPrivateCtxt ctxt(ctxt_size);

        // pick random IV for AES encryption
        random_bytes(ctxt.iv, KeyPrivateCtxt::IV_SIZE);
        
        // first, store Diffie-Hellman random R in ciphertext
        // TODO(Crypto): We might be able to avoid sending this by deriving r using the Monero based scheme too, I think.
        ctxt.R = r * p.encBase();

        // second, encrypt
        plusaes::encrypt_cbc(
            plaintext, ptxt_size,
            enc_key.getBuf(), KeyPrivateCtxt::KEY_SIZE, 
            &ctxt.iv,
            ctxt.buf.getBuf(), ctxt_size, true);

        logdbg << "Ciphertext size in bytes: " << ctxt_size << endl;

        return ctxt;
    }
}