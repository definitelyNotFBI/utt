#include <utt/Configuration.h>

#include <iostream>
#include <istream>
#include <ostream>

#include <utt/Params.h>

namespace libutt {
    bool Params::operator==(const Params& o) const {
        return
            g       == o.g &&
            g_tilde == o.g_tilde &&
            Y       == o.Y &&
            Y_tilde == o.Y_tilde &&
            h_1     == o.h_1 &&
            u       == o.u &&
            g_enc   == o.g_enc;

    }
}