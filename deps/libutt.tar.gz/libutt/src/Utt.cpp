#include <utt/Configuration.h>

#include <csetjmp>
#include <memory>
#include <optional>

#include <utt/internal/plusaes.h>
#include <utt/Params.h>
#include <utt/Keys.h>
#include <utt/Coin.h>
#include <utt/Utt.h>

#include <libfqfft/polynomial_arithmetic/basic_operations.hpp>

#include <xutils/NotImplementedException.h>

namespace libutt {

    Tx Tx::create(const Params& p, const std::vector<std::tuple<CoinSecrets, CoinComm, CoinSig>>& c, const std::vector<std::tuple<LTPK, Fr>>& recv) {
        size_t k = c.size();    // number of senders
        assertStrictlyGreaterThan(k, 1);
        size_t m = recv.size(); // number of recipients

        // create the TxOuts
        std::vector<TxOut> txouts;

        // pick EPK randomizers and compute EPKs for the receivers
        auto e = random_field_elems(m);
        std::vector<EPK> epk_dest;
        std::vector<G1>  epk_dh;
        bool computeG2 = true;
        for(size_t j = 0; j < m; j++) {
            auto& ltpk = std::get<0>(recv[j]);

            /**
             * NOTE(Alin): For now we pessimistically compute the EPK in G2 since we'll need it
             * to reconstruct an output coin commitment in G2 too, which we need for the security 
             * of PS over commitments.
             *
             * TODO(Crypto): ensure signing commitments in G1 (w/o ZKPoK via G2 commitment) is
             * secure. If we can forge a signature on an arbitrary message, then we can also 
             * forge a signature on a commitment.
             */
            epk_dest.push_back(ltpk.deriveEPK(p, e[j], computeG2));

            // The g^{e[i]} randomness will be stored in the TXN for the recipient to derive their ESK
            epk_dh.push_back(e[j] * p.pedEskBase1());
        }

        // split the input coin commitments cm_i = g_1^esk[i] g_2^val[i] g^r[i] into cm_i^val = g_2^val[i] g^t[i] for randomness t[i] and a nullifier u^esk[i]. We defer the proof for later.
        std::vector<CoinComm> icc_val;          // cm_i^val
        std::vector<Nullifier> nulls;           // nullifiers
        auto t = random_field_elems(k);
        for(size_t i = 0; i < k; i++) {
            auto& val = std::get<0>(c[i]).val;
            auto& esk = std::get<0>(c[i]).esk;

            // TODO(Performance): This can actually be pre-computed in the Wallet for each coin that will be spent later
            icc_val.emplace_back(p, val, t[i], false);
            nulls.emplace_back(p, esk);
        }

        // pick output commitment randomizers such that they have the same sum as the input coin randomizers
        std::vector<Fr> r_val = RangeProof::correlatedRandomness(t);

        // compute the output coin commitments
        std::vector<CoinComm> occ_val;
        for(size_t j = 0; j < m; j++) {
            auto& val = std::get<1>(recv[j]);

            occ_val.emplace_back(p, val, r_val[j], computeG2);

#ifndef NDEBUG
            logdbg << "Created out value-CoinComm: " << occ_val.back().ped1 << endl;
#endif

            // encrypt value and commitment randomness, which the receiver will need to spend the coin
            auto& ltpk = std::get<0>(recv[j]);
            auto ctxt = ltpk.encrypt(p, val, r_val[j]);

            // compute range proof for occ_val
            RangeProof range_pi(p, val, r_val[j]);

            // put everything in the txout
            txouts.emplace_back(epk_dest[j], occ_val.back(), ctxt, epk_dh[j], range_pi);
        }

        // compute a hash of all txouts
        std::string txOutsHash = TxOut::hashAll(txouts);

        logdbg << "Created TxOuts, with hash " << txOutsHash << endl;

        // create the TxIns
        std::vector<TxIn> txins;
        for(size_t i = 0; i < k; i++) {
            auto& secrets = std::get<0>(c[i]);
            auto& cc = std::get<1>(c[i]);
            auto& sig = std::get<2>(c[i]);

            // NOTE(Alin): We cannot aggregate these sigs, since they have to be verified for each input commitment, to ensure that commitment's epk is correct.
            SplitProof split_pi(p, nulls[i], icc_val[i], cc, secrets, t[i], txOutsHash);
             
            txins.emplace_back(nulls[i], icc_val[i], cc, sig, split_pi);
        }

        // save time copying by moving
        return Tx(std::move(txins), std::move(txouts));
    }

    bool Tx::verify(const Params& p, const BankPK& bpk) const {
        std::string txOutsHash = TxOut::hashAll(outs);

        // check coins are signed and commit to their revealed EPK
        for(size_t i = 0; i < ins.size(); i++) {
            // check PS16 sig on coin commitment, for each TxIn
            auto& cc = ins[i].cc;
            auto& sig = ins[i].sig;
            if(!sig.verify(p, cc, bpk)) {
                logerror << "One of the txins did not have a valid coinsig" << endl;
                return false;
            }

            // check revealed EPK is committed EPK, for each TxIn (and verify sig on txouts)
            auto& null = ins[i].null;
            auto& cm_val = ins[i].cm_val;
            auto& split_pi = ins[i].pi;
            if(!split_pi.verify(p, null, cm_val, cc, txOutsHash)) {
                logerror << "One of the txins did not have a valid SplitProof" << endl;
                return false;
            }
        }

        // check the sum of in and out commitments is the same 
        G1 incomms = G1::zero(), outcomms = G1::zero();
        for(size_t i = 0; i < ins.size(); i++) {
            incomms = ins[i].cm_val.ped1 + incomms;
        }

        for(size_t j = 0; j < outs.size(); j++) {
            outcomms = outs[j].cc_val.ped1 + outcomms;
        }

        if(incomms != outcomms) {
            logerror << "The in and out commitments disagreed on the sum of the values (or randomness)" << endl;
            return false;
        }

        for(size_t j = 0; j < outs.size(); j++) {
            // check recipient's EPK is indeed well-formed: it is not g_1^esk g_2^v for v != 0
            auto& epk = outs[j].epk;
            if(!EpkProof::verify(p, epk)) {
                logerror << "EPK commitment proof failed verifying" << endl;
                return false;
            }
        
            // check range proofs on out comms (in comms are good by invariant)
            auto& range_pi = outs[j].range_pi;
            auto& occ_val = outs[j].cc_val;
            if(!range_pi.verify(occ_val)) {
                logerror << "Range proof failed verifying" << endl;
                return false;
            }
        }

        return true;
    }

    void Tx::process(const Params& p, const BankSK& bsk) {
        for(size_t j = 0; j < outs.size(); j++) {
            // combine EPK and value commitments
            logdbg << "Creating coin commitment..." << endl;
            outs[j].cc = std::make_unique<CoinComm>(outs[j].epk, outs[j].cc_val);

            // issue new coin by signing combined commitment
            logdbg << "Signing coin commitment..." << endl;
            outs[j].sig = std::make_unique<CoinSig>(bsk.thresholdSignCoin(p, *outs[j].cc));
        }
    }

    std::optional<CoinSecrets> TxOut::isMine(const Params& p, const LTSK& ltsk) const {
        // decrypt the ciphertext
        Fr val, r;
        std::tie(val, r) = ctxt.decrypt(p, ltsk);

        // derive the ESK
        ESK esk = ltsk.deriveESK(p, epk_dh);

        // now we have all the coin secrets
        CoinSecrets secrets(esk, val, r);
    
        // TODO(Crypto): faster way to ensure this transaction is for you
        // implement AES-GCM-based consistency checking, rather than this slower (debug-only) check based on (esk, val, r) being in the coin commitment

        CoinComm cc_tmp(p, secrets);
        if(cc_tmp != *cc) {
            //logdbg << "This TxOut is not mine!" << endl;
            return {};
        }

        return secrets;
    }

    // TODO(Adithya): Currently, the last parameter `const BankPK&` is unused.
    // This results in clang with -Werror flag exiting the build
    std::tuple<CoinSecrets, CoinComm, CoinSig> TxOut::makeMine(const Params& p, const CoinSecrets& secrets, const BankPK& bpk) const {
        CoinSecrets secrets_r(secrets);
        CoinComm cc_r(*cc);

        // NOTE(Alin): TXN already comes with \Gr_2 counterpart of coin commitment, so we can verify PS16 signature
        // assertFalse(cc_r.hasG2());
        //cc_r.setG2(p, secrets_r);
        //assertTrue(cc_r.hasG2());
        
#ifndef NDEBUG
        // when debugging, check PS16 sig on 'cc' is valid
        if(!sig->verify(p, cc_r, bpk)) {
            // TODO(Alin): should this be an error condition rather than exception?
            throw std::runtime_error("Expected CoinSig to verify");
        }
#else
        (void)bpk; // To avoid compilation warnings turned to errors
#endif

        // re-randomize CoinComm under CoinSig (and update CoinSecrets)
        Fr r_delta = Fr::random_element();
        cc_r.rerandomize(p, r_delta);
        secrets_r.rerandomize(r_delta);

        // re-randomize CoinSig
        Fr u_delta = Fr::random_element();
        if(!hasCoinSig())
            throw std::runtime_error("Expected TxOut to have CoinSig by the time makeMine is called");

        CoinSig sig_r(*sig);
        sig_r.rerandomize(r_delta, u_delta);

        return std::make_tuple(secrets_r, cc_r, sig_r);
    }
        
    std::tuple<Fr, Fr> KeyPrivateCtxt::decrypt(const Params& p, const LTSK& ltsk) const {
        (void)p;
        // Compute the encryption key
        AutoBuf<unsigned char> enc_key = KeyPrivateCtxt::dhKex(R, ltsk.e);

        size_t ptxt_size = Fr_num_bytes() * 2;
        unsigned char ptxt[ptxt_size];

        // NOTE(Alin): I'm a bit confused, but I think I need to pass padding_size=0 so that 'decrypt_cbc' doesn't return the padding in the decrypted plaintext
        size_t padding_size = 0;
        plusaes::decrypt_cbc(
            buf.getBuf(), static_cast<size_t>(buf.size()),
            enc_key.getBuf(), static_cast<size_t>(enc_key.size()),
            &iv, 
            ptxt, ptxt_size,
            &padding_size);

        // Convert plaintext to Fr's 
        Fr val = Fr_deserialize(ptxt, Fr_num_bytes());
        Fr rand = Fr_deserialize(ptxt + Fr_num_bytes(), Fr_num_bytes());

        return std::make_tuple(val, rand);
    }
        
    std::string TxOut::hash() const {
        std::string ccHash = hashToHex(epk.toString()) + "|" +  hashToHex(cc_val.ped1);
        std::string ctxtHash = picosha2::hash256_hex_string(ctxt.buf.getBuf(), ctxt.buf.getBuf() + ctxt.buf.size());
        std::string epkDhHash = hashToHex(epk_dh);
        std::string rangeHash = range_pi.hash();

        std::string hashes = ccHash + "|" + epkDhHash + "|" + ctxtHash + "|" + rangeHash;
        return picosha2::hash256_hex_string(hashes);
    }

    std::string TxOut::hashAll(const std::vector<TxOut>& txouts) {
        std::string hashes;
        if(txouts.size() == 0)
            throw std::runtime_error("Need more than one TxOut to hash");

        hashes = txouts[0].hash();

        if(txouts.size() > 1) {
            for(size_t i = 0; i < txouts.size() - 1; i++) {
                hashes += "|" + txouts[i].hash();
            }
        }

        return picosha2::hash256_hex_string(hashes);
    }

} // end of libutt

std::istream& operator>>(std::istream& in, libutt::Tx& tx) {
    size_t ins_len, outs_len;
    in >> ins_len;
    libff::consume_OUTPUT_NEWLINE(in);

    tx.ins.reserve(ins_len);

    for(size_t i=0; i<ins_len;i++) {
        in >> tx.ins[i];
        libff::consume_OUTPUT_NEWLINE(in);
    }

    in >> outs_len;
    libff::consume_OUTPUT_NEWLINE(in);

    tx.outs.reserve(outs_len);

    for(size_t i=0; i<outs_len;i++) {
        in >> tx.outs[i];
        libff::consume_OUTPUT_NEWLINE(in);
    }

    return in;
}