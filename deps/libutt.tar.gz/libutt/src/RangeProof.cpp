#include <utt/Configuration.h>

#include <optional>

#include <utt/internal/plusaes.h>
#include <utt/Coin.h>
#include <utt/Params.h>
#include <utt/PolyCrypto.h>
#include <utt/RangeProof.h>

#include <libfqfft/polynomial_arithmetic/basic_operations.hpp>

#include <xutils/NotImplementedException.h>

namespace libutt {

    // TODO: remove these
    std::vector<G1> RangeProof::crs;
    std::vector<Fr> RangeProof::g;
    std::vector<Fr> RangeProof::q;
    G2 RangeProof::h;
    bool RangeProof::initialized;

    bool RangeProof::__init_vectors() {
        for(size_t i = 0; i < 2*RangeProof::MAX_BITS + 1; i++)
            crs.push_back(G1::random_element());

        g = random_field_elems(RangeProof::MAX_BITS + 1);
        q = random_field_elems(2*RangeProof::MAX_BITS + 1);

        h = G2::random_element();

        initialized = true;
        return true;
    }

    RangeProof::RangeProof(const Params& p, const Fr& val, const Fr& r) {
        (void)p;
        (void)val;
        (void)r;
        long n = static_cast<long>(RangeProof::MAX_BITS);

        // TODO: compute real proof

        // for now, just simulate some multiexps
        assertTrue(initialized);

        // commit to g(X) of degree n+1
        multiExp<G1>(crs.begin(), crs.begin() + (n+1), g.begin(), g.begin() + (n+1));

        // commit to q(X) of degree 2n+1
        multiExp<G1>(crs.begin(), crs.begin() + (2*n+1), q.begin(), q.begin() + (2*n+1));

        // prove g(\rho), g(\rho\omega), \hat{w}(\rho)
        // TODO: some field operations, ignored

        // 2 multiexps of size n
        multiExp<G1>(crs.begin(), crs.begin() + n, g.begin(), g.begin() + n);
        multiExp<G1>(crs.begin(), crs.begin() + n, g.begin(), g.begin() + n);

        // 1 multiexp of size 2n
        multiExp<G1>(crs.begin(), crs.begin() + (2*n), q.begin(), q.begin() + (2*n));
    }

    bool RangeProof::verify(const CoinComm& valComm) const {
        (void)valComm;
        // TODO: do real verification

        // for now, just simulate pairing-based checks, exps, etc
        assertTrue(initialized);

        // two G1 exps
        G1 result = g[0] * crs[0] + g[1] * crs[1];

        // six pairings
        assertStrictlyGreaterThan(crs.size(), 6);
        GT r1 = ReducedPairing(result, h);
        GT r2 = ReducedPairing(crs[2], h);
        GT r3 = ReducedPairing(crs[3], h);
        GT r4 = ReducedPairing(crs[4], h);
        GT r5 = ReducedPairing(crs[5], h);
        GT r6 = ReducedPairing(crs[6], h);

        return (r1 != r2) || (r3 != r4) || (r5 != r6);
    }
        
    std::vector<Fr> RangeProof::correlatedRandomness(const std::vector<Fr>& z) {
        std::vector<Fr> r;
        size_t k = z.size();
        
        Fr insum = Fr::zero(), outsum = Fr::zero();
        for(size_t i = 0; i < k - 1; i++) {
            insum = insum + z[i];

            r.push_back(Fr::random_element());
            outsum = outsum + r.back();
        }

        insum = insum + z[k - 1];
        Fr last = insum - outsum;
        r.push_back(last);

#ifndef DEBUG
        outsum = outsum + last;
        assertEqual(insum, outsum);
#endif
        return r;
    }
}


std::ostream& operator<<(std::ostream& out, const libutt::RangeProof& rpi) {
    // TODO: After rangeproof is implemented, do real serialization
    (void)rpi;

    return out;
}

std::istream& operator>>(std::istream& in, libutt::RangeProof& rpi) {
    // TODO: After rangeproof is implemented, do real deserialization
    (void)rpi;
    
    return in;
}