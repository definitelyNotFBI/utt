#include <utt/Configuration.h>

#include <libff/common/serialization.hpp>
#include <optional>

#include <utt/Bank.h>
#include <utt/Coin.h>
#include <utt/Utt.h>

#include <utt/PolyOps.h>

#include <libfqfft/polynomial_arithmetic/basic_operations.hpp>

#include <xutils/NotImplementedException.h>

namespace libutt {
        
    bool CoinSig::verify(const Params& p, const CoinComm& cc, const BankPK& pk) const {
        // checks the PS16 signature on the commitment in 'cc' (under 'pk')
        return ReducedPairing(second(), p.g_tilde) == ReducedPairing(first(), pk.X + cc.asG2());
    }

    bool CoinSigShare::verify(const Params& p, const CoinComm& cc, const BankSharePK& pk) const {
        // TODO(DkgHack): In practice, s3 = g^u would be agreed upon by the replicas doing the threshold signature, so it would be implicitly part of the CoinSigShare, rather than explicitly
        return ReducedPairing(s2, p.g_tilde) == ReducedPairing(s3, pk.X) * ReducedPairing(s1, cc.asG2());
    }
    
    CoinSig CoinSig::aggregate(size_t n, const std::vector<CoinSigShare>& sigShares, const std::vector<size_t>& signerIds) {
        // TODO(DkgHack): Right now, each signature share also stores g^u in CoinSigShare::s3. In a future version, the replicas will have a store of many g^u's that they all agree upon and can use.
        G1 s1 = sigShares.back().s3;

        //size_t t = signerIds.size();

        auto lagr = lagrange_coefficients_naive(n, signerIds);

        // prepare a G1 vector for the interpolation multiexp
        std::vector<G1> s2share;
        for(auto& sigShare : sigShares) {
            s2share.push_back(sigShare.s2);
        }

        G1 s2 = multiExp(s2share, lagr);
        return CoinSig(s1, s2);
    }
}

std::ostream& operator<<(std::ostream& out, const libutt::CoinSigShare& coinShare) {
    out << coinShare.s1 << endl;
    out << coinShare.s2 << endl;
    out << coinShare.s3 << endl;
    return out;
}

std::istream& operator>>(std::istream& in, libutt::CoinSigShare& coinShare) {
    in >> coinShare.s1;
    libff::consume_OUTPUT_NEWLINE(in);

    in >> coinShare.s2;
    libff::consume_OUTPUT_NEWLINE(in);
    
    in >> coinShare.s3;
    libff::consume_OUTPUT_NEWLINE(in);

    return in;
}

std::ostream& operator<<(std::ostream& out, const libutt::CoinSig& coinShare) {
    out << coinShare.s1 << endl;
    out << coinShare.s2 << endl;
    return out;
}

std::istream& operator>>(std::istream& in, libutt::CoinSig& coinShare) {
    in >> coinShare.s1;
    libff::consume_OUTPUT_NEWLINE(in);

    in >> coinShare.s2;
    libff::consume_OUTPUT_NEWLINE(in);
    
    return in;
}

std::ostream& operator<<(std::ostream& out, const libutt::Nullifier& null) {
    out << null.n << endl;
    return out;
}

std::istream& operator>>(std::istream& in, libutt::Nullifier& null) {
    in >> null.n;
    libff::consume_OUTPUT_NEWLINE(in);

    return in;
}