#include <utt/Configuration.h>

#include <fstream>
#include <istream>
#include <ostream>
#if __has_include(<filesystem>)
    #include <filesystem>
    namespace fs = std::filesystem;
#elif __has_include(<experimental/filesystem>)
  #include <experimental/filesystem> 
  namespace fs = std::experimental::filesystem;
#else
  error "Missing the <filesystem> header."
#endif

#include <utt/Params.h>
#include <utt/Keys.h>
#include <utt/Bank.h>
#include <utt/Coin.h>
#include <utt/PolyOps.h>

#include <xutils/Utils.h>

namespace libutt {

    BankPK BankSK::toPK(const Params& p) const {
        return BankPK(x * p.ps16Base2());
    }

    CoinSig BankSK::thresholdSignCoin(const Params& p, const CoinComm& cc) const {
        Fr u = Fr::random_element(); // pick 'u' randomly (in practice, player i has g^u and u_i share of u from DKG)

        // In practice, player i has (1) share x_i of PS16 secret key x, and (2) g^u and share u_i of u
        // Then, a PS16 *signature share* on commitment C, with randomness u is:
        //   (\sigma_{i,1}, \sigma_{i,2}) = (g^{u_i}, (g^u)^{x_i} C^{u_i})

        // Instead, we simulate the time to compute such a share by computing:
        //   (\sigma_1, \sigma_2) = (g^u, (g^u)^x C^u)

        // TODO(Crypto): Figure out if ZKPoK is needed here. If so, does the pairing-based check between G1 and G2 commitments suffice?

        return thresholdSignCoin(p, cc, u);
    }
    
    CoinSig BankSK::thresholdSignCoin(const Params& p, const CoinComm& cc, const Fr& u) const {
        G1 h = u * p.ps16Base1();
        
        return CoinSig(
            h,
            x * h + u * cc.ped1
        );
    }
    
    BankThresholdKeygen::BankThresholdKeygen(const Params& p, size_t t, size_t n)
        : sk(Fr::zero()), p(p)
    {
        // degree t-1 polynomial f(X) such that t players can reconstruct f(0) = s, which encodes the bank's secret key s
        std::vector<Fr> poly_f = random_field_elems(t);

        // TODO(DkgHack): We use this to pick a g^u that each PS16 signature will (insecurely) use in our demo. In practice a DKG should be used to generate this.
        std::vector<Fr> poly_u = random_field_elems(t);

        // evaluate it at n pre-determined points (i.e., Nth roots of unity, with smallest N = 2^k >= n)
        std::vector<Fr> evals_f, evals_u;
        poly_fft(poly_f, n, evals_f);
        poly_fft(poly_u, n, evals_u);

        // the secret key is f(0)
        sk.x = poly_f[0];
        u = poly_u[0];

        // TODO(DkgHack): do not hardcode g^u like this into BankShareSK
        auto gToU = u * p.ps16Base1();

        // the ith server's key is evals_u[i] = f(\omega_N^i)
        for(size_t i = 0; i < n; i++) {
            BankShareSK skShare(evals_f[i], gToU, evals_u[i]);

            // skShare.x = evals_f[i];
            // skShare.shareU = evals_u[i];
            // skShare.gToU = gToU;

            skShares.push_back(skShare);
            //pkShares.push_back(skShare.toSharePK(p));
        }
    }

    BankPK BankThresholdKeygen::aggregate(
            size_t n,
            std::vector<size_t> &ids, 
            std::vector<BankSharePK> &pkShares
        ) 
    {
        std::cout << "Reached " << 1 << std::endl;
        auto lagr = lagrange_coefficients_naive(n, ids);
        std::cout << "Reached " << 2 << std::endl;
        
        std::vector<G2> g2Shares;
        g2Shares.reserve(pkShares.size());
        for(auto& pk: pkShares) {
            g2Shares.push_back(pk.X);
        }
        std::cout << "Reached " << 3 << std::endl;

        printf("lagr size: %lu\nshareSize: %lu\n", lagr.size(), g2Shares.size());
        // Multiexp with the pks to get the pk
        G2 X = multiExp(g2Shares, lagr);
        BankPK pk(X);
        return pk;
    }
        
    void BankThresholdKeygen::writeToFiles(const std::string& dirPath, const std::string& fileNamePrefix) const {
        for(size_t i = 0; i < skShares.size(); i++) {
            std::string filePath = dirPath;
            filePath += "/";
            filePath += fileNamePrefix + std::to_string(i);

            loginfo << "Writing params and SK for replica #" << i << " to " << filePath << endl;

            // make sure the file does not already exist, since we do not want to accidentally overwrite other secrets
            fs::path fsp(filePath);
            if(fs::exists(fsp)) {
                logerror << "Output file " << filePath << " should not exist." << endl;
                throw std::runtime_error("File already exists");
            }

            std::ofstream fout(filePath);

            fout << p;
            fout << skShares[i];
            fout << getPK(p);
        }
    }

    CoinSigShare BankShareSK::sign(const Params& p, const CoinComm& cc) const {
        auto gToUshare = shareU * p.ps16Base1();

        return CoinSigShare(
            gToUshare,
            x * gToU + shareU * cc.asG1(),
            gToU
        );
    }
}