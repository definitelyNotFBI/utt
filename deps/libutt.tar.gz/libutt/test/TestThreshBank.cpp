#include <utt/Configuration.h>

#include <utt/PolyCrypto.h>
#include <utt/PolyOps.h>
#include <utt/Utt.h>

#include <utt/Utils.h>

#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <random>
#include <stdexcept>
#include <vector>

#include <xassert/XAssert.h>
#include <xutils/Log.h>
#include <xutils/NotImplementedException.h>
#include <xutils/Timer.h>
#include <xutils/Utils.h>

using namespace std;
using namespace libfqfft;
using namespace libutt;

void testCoinThreshSig(size_t t, size_t n) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<long> udi(1, 1024);

    auto p = libutt::Params::Random();   // randomly generated parameters
    CoinSecrets c(p, udi(gen));    // randomly generated coin

    std::cout << "Random coin value: " << c.val << endl;

    CoinComm cc(p, c);    // commit to the coin using the specified parameters

    testAssertTrue(cc.hasCorrectG2(p));

    std::cout << "Pedersen in G1: " << cc.ped1 << endl;
    std::cout << "Pedersen in G2: " << cc.ped2 << endl;

    // create a threshold bank
    BankThresholdKeygen kg(p, t, n);

    BankPK pk = kg.getPK(p);
    std::vector<BankShareSK> skShares = kg.getAllShareSKs();
    std::vector<BankSharePK> pkShares;
    std::vector<CoinSigShare> sigShares;

    for(size_t i = 0; i < n; i++) {
        pkShares.push_back(skShares[i].toSharePK(p));
        sigShares.push_back(skShares[i].sign(p, cc));

        loginfo << "id" << i << ": "
            << skShares[i].toSharePK(p) << endl;

        testAssertTrue(sigShares.back().verify(p, cc, pkShares.back()));
    }

    std::vector<size_t> signerIds = random_subset(t, n);
    std::vector<CoinSigShare> subsetSigShares;
    for(auto id : signerIds) {
        loginfo << id << endl;
        subsetSigShares.push_back(sigShares[id]);
    }

    CoinSig threshSig1 = CoinSig::aggregate(n, subsetSigShares, signerIds);

    // also sign naively and make sure aggregated signature matches
    BankSK sk = kg.sk;
    Fr u = kg.u;
    CoinSig threshSig2 = sk.thresholdSignCoin(p, cc, u);

    if(threshSig1 != threshSig2) {
        testAssertFail("Threshold signature did not match normal signature");
    }
    testAssertTrue(threshSig2.verify(p, cc, pk));

    // assert threshold signature verifies as normal signature
    testAssertTrue(threshSig1.verify(p, cc, pk));

    // sign the coin
    //CoinSig scc = sk.thresholdSignCoin(p, cc);
}

int main(int argc, char *argv[]) {
    libutt::initialize(nullptr, 0);
    //srand(static_cast<unsigned int>(time(NULL)));
    (void)argc;
    (void)argv;

    size_t t = 12;
    size_t n = 20;
    testCoinThreshSig(t, n);

    loginfo << "All is well." << endl;

    return 0;
}


/*
alias emake='cd libutt && ./scripts/docker/install.sh && cd ..'
alias dmake='make -f Makefile.docker'
*/