#pragma once

#include <array>
#include <cstdlib>
#include <iostream>
#include <optional>
#include <ostream>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>

#include <utt/PolyCrypto.h>

#include <xassert/XAssert.h>
#include <xutils/Log.h>

namespace libutt {

    class Params {
    public:
        G1 g;       // used as the randomizer base in Pedersen commitments and as the base for the secret key in PS16
        G2 g_tilde; // used as the base for the PKs in PS16

        std::vector<G1> Y;       // Y[0] = g^{y_1} = g_1, Y[1] = g^{y_2} = g_2, Y[2] = g (i.e., the Pedersen bases for the ESK, the coin's denomination, and the commitment randomness)
        std::vector<G2> Y_tilde; // same as above, except using g_tilde rather than g 

        /**
         * Used to prove that a possibily malicious EPK = g_1^esk g_2^v always has g_2^v = 0
         * by recommitting as epkpi = h_1^esk in \Gr_2 and checking that:
         *      $$e(epk, h_1) = e(g_1,  epkpi)$$
         */
        G2 h_1;

        G1 u;       // used to compute a nullifier as u^esk

        G1 g_enc;   // used as the base for the PK 'g_enc^e' of the key-private encryption scheme

        static const size_t numBases = 3;

    public:
        Params static Random() {
            Params p;

            // pick the PS16 g and \tilde{g} bases for the SK and PKs
            p.g = G1::random_element();
            p.g_tilde = G2::random_element();
            p.u = G1::random_element();

            std::vector<Fr> y;
            // picks Y_i = g^{y_i} in G_1 and G_2
            for (decltype(Y.size()) i = 0; i < p.Y.size() - 1; i++) {
                y.push_back(Fr::random_element());

                p.Y[i] = y[i] * p.g;
                p.Y_tilde[i] = y[i] * p.g_tilde;
            }
            // used to prove that a maliciously-derived EPK (e.g., epk = g_1^esk g_2^v) does not have v != 0
            p.h_1 = G2::random_element();

            // useful to store these like this for multiExp calls on Y and Y_tilde when computing Pedersen commitments
            p.Y[numBases - 1] = p.g;
            p.Y_tilde[numBases - 1] = p.g_tilde;

            return p;
        }

    public:
        G1 ps16Base1() const { return g; }
        G2 ps16Base2() const { return g_tilde; }

        G1 pedLtskBase1() const { return Y[0]; }
        G2 pedLtskBase2() const { return Y_tilde[0]; }

        G1 pedEskBase1() const { return pedLtskBase1(); }
        G2 pedEskBase2() const { return pedLtskBase2(); }

        G1 pedDenomBase1() const { return Y[1]; }
        G2 pedDenomBase2() const { return Y_tilde[1]; }

        G1 pedRandBase1() const { return ps16Base1(); }
        G2 pedRandBase2() const { return ps16Base2(); }

        G1 encBase() const { return g_enc; }

        G1 nullifBase() const { return u; }

        G2 pokEskBase2() const { return h_1; }

    public:
        bool operator==(const Params& o) const;

        bool operator!=(const Params& o) const {
            return !operator==(o);
        }

    // Add serialization/deserailization
    protected:
        Params() {
            this->Y.resize(numBases);
            this->Y_tilde.resize(numBases);
        }
    public:
        static Params FOR_DESERIALIZATION_ONLY() { return Params(); }
        void write(std::ostream& out) const;
        void read(std::istream& in);
        Params(std::istream& in);
        friend std::ostream& operator<<(std::ostream& out, const libutt::Params& p);
        friend std::istream& operator>>(std::istream& in, libutt::Params& p);
    };

}


