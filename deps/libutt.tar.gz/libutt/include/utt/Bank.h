#pragma once

#include <array>
#include <cstdlib>
#include <istream>
#include <optional>
#include <ostream>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>

#include <utt/PolyCrypto.h>
#include <utt/Params.h>
#include <utt/Coin.h>
#include "utt/Serialization.h"

#include <xassert/XAssert.h>
#include <xutils/AutoBuf.h>
#include <xutils/Log.h>
#include <xutils/NotImplementedException.h>

namespace libutt {

    class BankPK;

    /**
     * The PS16 secret key that the bank uses to sign a coin.
     * NOTE: We assume PS16 is used to sign commitments, so the SK is just x, rather than (x, y_1, y_2, \dots, y_\ell)
     */
    class BankSK {
    public:
        Fr x;

    public:
        BankSK(const Fr& x) : x(x) {}
    //    BankSK() : x(Fr::zero()) {}

    public:
        static BankSK random() {
            BankSK sk(Fr::random_element());
            return sk;
        }

    public:
        BankPK toPK(const Params& p) const;

        /**
         * WARNING: This returns X = g^x, which is *still* the secret key!
         */
        G1 asSecretGroupElement(const Params& p) const {
            return x * p.ps16Base1();
        }

        /**
         * WARNING: This merely simulates an ideal-case threshold signature by 
         * 'pretending' one of the replicas is signing (and assuming other replicas
         * are signing in parallel + ignoring time to aggregate threshold signature).
         */
        CoinSig thresholdSignCoin(const Params& p, const CoinComm& cc) const;
        CoinSig thresholdSignCoin(const Params& p, const CoinComm& cc, const Fr& u) const;

    // Serialization and Deserialization techniques
    protected:
        BankSK() {}
    public:
        static BankSK FOR_DESERIALIZATION_ONLY() { return BankSK(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        BankSK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::BankSK&);
        friend std::istream& operator>>(std::istream&, libutt::BankSK&);
    };

    /**
     * The PS16 public key that the BFT quorum uses to verify coins.
     * NOTE: Needs the same base as the Pedersen commitment randomizer
     */
    class BankPK {
    public:
        G2 X;

    public:    
        BankPK(const G2& X) : X(X) {}

        BankPK(const Params& p, const BankSK &sk) {
           X = sk.x * p.ps16Base2();
        }

    // Serialization and Deserialization techniques
    protected:
        BankPK() {}
    public:
        static BankPK FOR_DESERIALIZATION_ONLY() { return BankPK(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        BankPK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::BankPK&);
        friend std::istream& operator>>(std::istream&, libutt::BankPK&);
    };

    class BankSharePK : public BankPK {
    public:
        BankSharePK(const Params& p, const BankSK& sk)
            : BankPK(p, sk)
        {
        }

    // Add serialization/deserailization
    protected:
        BankSharePK() {}
    public:
        static BankSharePK FOR_DESERIALIZATION_ONLY() { return BankSharePK(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        BankSharePK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::BankSharePK&);
        friend std::istream& operator>>(std::istream&, libutt::BankSharePK&);
    };

    class BankShareSK : public BankSK {
    public:
        G1 gToU;    // TODO(DkgHack): Recall that we have a hack where each BankShareSK stores its u_i and the g^u interpolated from these u_i's
        Fr shareU;  // the u_i share of the u from above

    public:
        BankShareSK(const Fr& x, const G1& gToU, const Fr& shareU)
            : BankSK(x), gToU(gToU), shareU(shareU) {}
    public:
        // A bit stupid, but cannot use parent class's BankSK::toPK() which returns a BankPK not a BankSharePK (and don't want to use complicated design patterns either)
        BankSharePK toSharePK(const Params& p) const {
            return BankSharePK(p, *this);
        }

        CoinSigShare sign(const Params& p, const CoinComm& cc) const;

    public:
        bool operator==(const BankShareSK& o) const {
            return 
                gToU == o.gToU &&
                shareU == o.shareU &&
                x == o.x;
        }

        bool operator!=(const BankShareSK& o) const {
            return !operator==(o);
        }

    // Add serialization/deserailization
    protected:
        BankShareSK(): BankSK() {}
    public:
        static BankShareSK FOR_DESERIALIZATION_ONLY() { return BankShareSK(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        BankShareSK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::BankShareSK&);
        friend std::istream& operator>>(std::istream&, libutt::BankShareSK&);
    };


    // class BankPublicInfo {
    // public:
    //     Params p;
    //     std::vector<BankPK> pub_keys;
    // private: 
    //     size_t n;
    // }

    class BankThresholdKeygen {
    public:
        BankSK sk;
        std::vector<BankShareSK> skShares;
        Fr u;
        Params p;
        //std::vector<BankSharePK> pkShares;

    public:
        BankThresholdKeygen(const Params& p, size_t t, size_t n);

    public:
        BankPK getPK(const Params& p) const { return sk.toPK(p); }

        /**
         * Returns the share of the SK/PK for the i'th server, with i \in \{0, 1, 2, \dots, n-1\}
         */
        //std::tuple<BankShareSK, BankSharePK> getKeyPair(size_t i) const {
        //    return std::make_tuple(skShares.at(i), pkShares.at(i));
        //}

        BankShareSK getShareSK(size_t i) const {
            return skShares.at(i);
        }
        
        std::vector<BankShareSK> getAllShareSKs() const { return skShares; }

        /**
         * Writes the key-pair of each server 'i' in dirPath + '/' + fileNamePrefix + std::to_string(i), for all i \in [0,n)
         */
        void writeToFiles(const std::string& dirPath, const std::string& fileNamePrefix) const;

        static BankPK aggregate(
            size_t n,
            std::vector<size_t> &ids, 
            std::vector<BankSharePK> &pkShares
        );
    };
}