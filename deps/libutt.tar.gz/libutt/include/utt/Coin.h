#pragma once

#include <array>
#include <cstdlib>
#include <memory>
#include <optional>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>
#include "PolyCrypto.h"

#include <utt/PolyCrypto.h>
#include <utt/Params.h>
#include <utt/Keys.h>
#include <utt/Serialization.h>

#include <xassert/XAssert.h>
#include <xutils/Log.h>

namespace libutt {

    // TODO: Wallet.h with a Wallet class which stores collection of WalletCoin objects, which are a tuple of CoinSecrets/Comm/Sig.

    class CoinComm;
    class ESK;
    class EPK;
    
    /**
     * The private information associated with a coin, whose knowledge is necessary for spending it.
     */
    class CoinSecrets {
    public:
        ESK esk;    // owner (i.e., LTSK) + serial number (i.e., ESK randomizer)
        Fr val;     // denomination
        Fr r;       // randomness used to commit to the coin

    protected:
        std::optional<EPK> epk;    // associated EPK, to avoid redundant exp

    public:
        /**
         * Randomly generates a coin.
         * Used for testing only.
         * TODO: rename to random()
         */
        CoinSecrets(const Params& p, long v = 1024*2)
            : esk(ESK::random()), // random by default constructor
              val(Fr(v)),
              r(Fr::random_element()),
              epk(esk.toEPK(p))
        {
        }

        CoinSecrets(const ESK& esk, const Fr& val, const Fr& r)
            : esk(esk), val(val), r(r)
        {}
    public:
        bool hasEpk() const { return epk.has_value(); }

        const EPK& getEpk() const { testAssertTrue(hasEpk()); return epk.value(); }

        void rerandomize(const Fr& r_delta) { r = r + r_delta; }

    protected:
        CoinSecrets(): esk(ESK::random()) {}
    public:
        void write(std::ostream&) const;
        void read(std::istream&);
        CoinSecrets(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::CoinSecrets&);
        friend std::istream& operator>>(std::istream&, libutt::CoinSecrets&);
    };
    

    /**
     * A Pedersen commitment to a Coin: g_1^esk g_2^value g^r
     * We also use this as a partial commitment to the either ESK or to value.
     */
    class CoinComm {
    public:
        G1 ped1;
        // TODO: change to std::optional
        G2 ped2;    // the same commitment, but in G2

    public:
        CoinComm(const Params& p, const long val, const Fr& r, bool withG2 = true): CoinComm(p, Fr(val), r, withG2) 
        {}

        // Use this constructor to create commitments to a value with esk=0 (During minting/payment)
        CoinComm(const Params& p, const Fr& val, const Fr& r, bool withG2 = true)
        {
            // FIXME: For some reason, I can no longer use the STL iterators over G1/Fr vectors, I think due to some missing default constructors in libff which C++17 borks on.
            // This is why the code below (as well as other code) is awkwardly setting up subvectors.
            ped1 = multiExp(
                p.pedDenomBase1(), p.pedRandBase1(),
                val, r);

            if(withG2) {
                ped2 = multiExp(
                    p.pedDenomBase2(), p.pedRandBase2(),
                    val, r);
            } else {
                ped2 = G2::zero();
            }
        }

        /**
         * Builds a coin commitment from an EPK, a coin value and a commitment randomizer
         */
        CoinComm(const Params& p, const EPK& epk, const Fr& val, const Fr& r, bool withG2 = true)
            : CoinComm(p, val, r, withG2)
        {
            ped1 = ped1 + epk.asG1();

            if(withG2) {
                ped2 = ped2 + epk.asG2();
            }
        }

        // Build a commitment of the form g_1^esk * g_2^v * g^r with r=0
        // This is used in the BFT setting by the replicas during Minting
        CoinComm(const Params& p, const EPK& epk, long val, bool withG2 = true): CoinComm(p, epk, Fr(val), Fr::zero(), withG2) {}

        /**
         * When processing a TXN after it is verified, we need to compute    
         * the output coin commitment to be signed by combining the EPK and 
         * value commitments.
         */
        CoinComm(const EPK& epk, const CoinComm& valComm)
            : ped1(epk.asG1() + valComm.ped1), ped2(epk.asG2() + valComm.asG2())
        {
        }

        /**
         * Builds a coin commitment from a coin.
         * Currently used for testing only.
         */
        CoinComm(const Params& p, const CoinSecrets& secrets) {
            setG1(p, secrets);
            setG2(p, secrets);
        }

    public:
        G1 asG1() const { return ped1; }

        G2 asG2() const { testAssertTrue(hasG2()); return ped2; }
        bool hasG2() const { return ped2 != G2::zero(); }

        /**
         * Computes the Pedersen commitment in \Gr_1 to the coin: 
         *      $$g_1^{esk.z} g_2^{val} g^r$$
         */
        void setG1(const Params& p, const CoinSecrets& secrets) {
            std::vector<Fr> exps = { secrets.esk.s, secrets.val, secrets.r };
            assertEqual(exps.size(), p.Y.size());

            ped1 = multiExp<G1>(p.Y, exps);
            // i.e., ped1 = (c.esk.s * p.pedLtskBase1()) + (c.esk.z * p.pedEskBase1()) + (c.val * p.pedDenomBase1()) + (c.r * p.pedRandBase1());
        }

        void setG2(const Params& p, const CoinSecrets& secrets) {
            std::vector<Fr> exps = { secrets.esk.s, secrets.val, secrets.r };
            assertEqual(exps.size(), p.Y_tilde.size());

            ped2 = multiExp<G2>(p.Y_tilde, exps);
            assertTrue(hasCorrectG2(p));
        }

        /**
         * Checks that the G2 counterpart of the commitment in G1 is indeed a commitment to the same messages
         */
        bool hasCorrectG2(const Params& p) const {
            for(auto& y: p.Y_tilde) {
                testAssertNotEqual(y, G2::zero());
            }
            testAssertTrue(hasG2());
            return ReducedPairing(ped1, p.g_tilde) == ReducedPairing(p.g, ped2);
        }

        void rerandomize(const Params& p, const Fr& r_delta) {
            ped1 = ped1 + r_delta * p.pedRandBase1();
            if(hasG2())
                ped2 = ped2 + r_delta * p.pedRandBase2();
        }

        bool operator==(const CoinComm& other) const {
            //if(!hasCorrectG2() || !other.hasCorrectG2())
            //    throw std::runtime_error("Incorrect G2 counterpart in coin comm");
            // TODO: figure out semantics for ped2 counterpart

            return ped1 == other.ped1;
        }

        bool operator!=(const CoinComm& other) const {
            return !operator==(other);
        }

        // WARNING: Not for serializing CoinComms b.c. does not output G2 counterparts
        std::string toString() const {
            std::stringstream ss;
            ss << ped1;
            return ss.str();
        }

        // Serialization and Deserialization techniques
        protected:
            CoinComm() {}
        public:
            static CoinComm FOR_DESERIALIZATION_ONLY() { return CoinComm(); }
            void write(std::ostream&) const;
            void read(std::istream&);
            CoinComm(std::istream&);
            friend std::ostream& operator<<(std::ostream&, const libutt::CoinComm&);
            friend std::istream& operator>>(std::istream&, libutt::CoinComm&);
    };

    class BankPK;
    class BankSharePK;

    class CoinSigShare;

    /**
     * A PS16 signature on a CoinComm and therefore on a CoinSecrets object
     */
    class CoinSig {
    public:
        G1 s1;  // i.e., h = g^u
        G1 s2;  // i.e., h^{x + \sum_i m_i y_i}

    public:
        CoinSig(const G1& g1, const G1& g2) : s1(g1), s2(g2) {}

        CoinSig(const CoinSig& other)
            : s1(other.s1), s2(other.s2)
        {}

        CoinSig(CoinSig&& other)
            : s1(std::move(other.s1)), s2(std::move(other.s2))
        {}

    public:
        G1 first() const  { return s1; }
        G1 second() const { return s2; }

        void rerandomize(const Fr& r_delta, const Fr& u_delta) { 
            s1 = u_delta * s1;
            // s2 = (s2 * s1^r_delta)^u_delta
            //    = s2^u_delta s1^{r_delta * u_delta}
            s2 = multiExp(s2, s1, u_delta, r_delta * u_delta);
        }

        /**
         * Checks the PS16 signature by the bank on the specified coin
         */
        bool verify(const Params& p, const CoinComm& cc, const BankPK& pk) const;

        /**
         * Aggregates a threshold signature from a subset of size 't' of the total 'n' replicas.
         * The size-t subset of {0, 1, ..., n-1} of replicas IDs is in 'signerIds'.
         * Specifically, sigShares[i] is the signature share computed by the replica with ID signerIds[i].
         */
        static CoinSig aggregate(size_t n, const std::vector<CoinSigShare>& sigShares, const std::vector<size_t>& signerIds);

    public:
        bool operator==(const CoinSig& o) const {
            return s1 == o.s1 && s2 == o.s2;
        }
        bool operator!=(const CoinSig& o) const {
            return !operator==(o);
        }

    // Serialization and Deserialization techniques
    protected:
        CoinSig() {}
    public:
        static CoinSig FOR_DESERIALIZATION_ONLY() { return CoinSig(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        CoinSig(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::CoinSig&);
        friend std::istream& operator>>(std::istream&, libutt::CoinSig&);
    }
    ;
    /**
     * A PS16 signature *share* on a CoinComm and therefore on a CoinSecrets object
     */
    class CoinSigShare {
    public:
        G1 s1;  // i.e., h_i = g^{u_i}
        G1 s2;  // i.e., h^{x_i} (\prod_i g_i^m_i g^r)^{u_i}
        G1 s3;  // i.e., h = g^u

    public:
        CoinSigShare(const G1& g1, const G1& g2, const G1& g3) : s1(g1), s2(g2), s3(g3) {}

    public:
        /**
         * Checks the PS16 signature *share* by the i'th bank on the specified coin
         */
        bool verify(const Params& p, const CoinComm& cc, const BankSharePK& pk) const;

    // Serialization and Deserialization techniques
    protected:
        CoinSigShare() {}
    public:
        void write(std::ostream&) const;
        void read(std::istream&);
        CoinSigShare(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::CoinSigShare&);
        friend std::istream& operator>>(std::istream&, libutt::CoinSigShare&);
    };

    /**
     * When a coin (esk, val) is spent, it must be marked as 'spent' by the bank.
     * This is done by (1) deriving a privacy-preserving nullifier u^esk which is not linkable to the EPK g_1^esk (which was revealed in the TXN that created the coin) and (2) adding this nullifer to a 'spent list'
     */
    class Nullifier {
    public:
        G1 n;

    public:
        Nullifier(const Params &p, const ESK& esk)
            : n(esk.s * p.nullifBase())
        {
        }

    public:
        std::string toString() const {
            std::stringstream ss;
            ss << n;
            return ss.str();
        }

    // Serialization and Deserialization techniques
    protected:
        Nullifier() {}
    public:
        static Nullifier FOR_DESERIALIZATION_ONLY() { return Nullifier(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        Nullifier(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::Nullifier&);
        friend std::istream& operator>>(std::istream&, libutt::Nullifier&);
    };
}