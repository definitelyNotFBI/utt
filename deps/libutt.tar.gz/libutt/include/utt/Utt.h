#pragma once

#include <array>
#include <cstdlib>
#include <optional>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>

#include <utt/Bank.h>
#include <utt/Coin.h>
#include <utt/Params.h>
#include <utt/PolyCrypto.h>
#include <utt/RangeProof.h>

#include <xassert/XAssert.h>
#include <xutils/AutoBuf.h>
#include <xutils/Log.h>
#include <xutils/NotImplementedException.h>

namespace libutt {
    
    /**
     * We use this to keep track of which library version the benchmark numbers were for.
     * Actually, upon further thought, this should be much more flexible and be given as input
     * to the benchmarks.
     */
    //constexpr static const char * Version = "may24pres";

    /**
     * Proof for a revealed EPK being the committed EPK.
     */
    class SplitProof {
    public:
        Fr h;
        Fr a;
        Fr b;

    public:
        SplitProof(const Params& p, const Nullifier& null, const CoinComm& cm_val, const CoinComm& cc, const CoinSecrets& secrets, const Fr& t, const std::string& msgToSign) {
            Fr alpha = Fr::random_element();
            Fr beta  = Fr::random_element();

            // A = u^\alpha and B = g_1^\alpha g^\beta
            G1 A = alpha * p.nullifBase();
            G1 B = multiExp(p.pedEskBase1(), p.pedRandBase1(), alpha, beta);

            // TODO(Crypto): Incorporate commitment keys too inside hash (maybe add a coinCkHash() method to Params)
            h = hash(null, cm_val, cc, A, B, msgToSign);

            a = alpha + h * secrets.esk.s;
            b = beta + h * (secrets.r - t);
        }

    public:
        bool verify(const Params& p, const Nullifier& null, const CoinComm& cm_val, const CoinComm& cc, const std::string& msgSigned) const {
            G1 A = (a * p.nullifBase()) - (h * null.n);
            G1 B = multiExp(p.pedEskBase1(), p.pedRandBase1(), a, b) - (h * (cc.ped1 - cm_val.ped1));

            return h == hash(null, cm_val, cc, A, B, msgSigned);
        }

        Fr hash(const Nullifier& null, const CoinComm& cm_val, const CoinComm& cc, const G1& A, const G1& B, const std::string& msg) const {
            return hashToField(null.toString() + "|" + cm_val.toString() + "|" + cc.toString() + "|" + hashToHex(A) + "|" + hashToHex(B) + "|" + msg);
        }

    // Serialization and Deserialization techniques
    protected:
        SplitProof() {}
    public:
        static SplitProof FOR_DESERIALIZATION_ONLY() { return SplitProof(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        SplitProof(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::SplitProof&);
        friend std::istream& operator>>(std::istream&, libutt::SplitProof&);
    };

    /**
     * A key-private encryption of the coin commitment randomness, the EPK and its value
     */
    class KeyPrivateCtxt {
    public:
        constexpr static size_t IV_SIZE = 16;
        constexpr static size_t KEY_SIZE = 32;

    public:
        G1 R;                   // g^r, which we raise to ltsk.e to get the Diffie-Hellman shared secret
        unsigned char iv[IV_SIZE];
        AutoBuf<unsigned char> buf;   // AES ciphertext, under H_aes(g^{r ltsk.e})

    public:
        KeyPrivateCtxt(size_t size) : buf(size) {}

    public:
        /**
         * The ciphertext encryption key is a DH shared key obtained from the LTPK's encryption key and a random key picked by the encryptor.
         */
        static AutoBuf<unsigned char> dhKex(const G1& pk1, const Fr& sk2) {
            G1 dh = sk2 * pk1;

            // hash DH key to bytes
            AutoBuf<unsigned char> enc_key(KeyPrivateCtxt::KEY_SIZE); 
            hashToBytes(dh, enc_key.getBuf(), KeyPrivateCtxt::KEY_SIZE);

            return enc_key;
        }

    public:
        /**
         * Decrypts the coin value and the Pedersen randomness.
         */
        std::tuple<Fr, Fr> decrypt(const Params& p, const LTSK& ltsk) const;

    // Serialization and Deserialization techniques
    protected:
        KeyPrivateCtxt() {}
    public:
        static KeyPrivateCtxt FOR_DESERIALIZATION_ONLY() { return KeyPrivateCtxt(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        KeyPrivateCtxt(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::KeyPrivateCtxt&);
        friend std::istream& operator>>(std::istream&, libutt::KeyPrivateCtxt&);
    };

    class TxIn {
    public:
        Nullifier null; // nullifier that can be used to keep track of the coin as spent
        CoinComm cm_val;// commitment to coin's value g_2^v g^t
        CoinComm cc;    // commitment to coin g_1^esk g_2^v g^r
        CoinSig sig;    // signature on the coin commitment 'cc'
        SplitProof pi;  // proof that the coin committed in 'cc' was correctly split into a nullifier u^esk and a commitment to the value/denomination v

    public:
        TxIn(const Nullifier& null, const CoinComm& cm_val, const CoinComm& cc, const CoinSig& sig, const SplitProof& pi)
            : null(null), cm_val(cm_val), cc(cc), sig(sig), pi(pi)
        {}

    // Serialization and Deserialization techniques
    protected:
        TxIn() :null(Nullifier::FOR_DESERIALIZATION_ONLY()),
            cm_val(CoinComm::FOR_DESERIALIZATION_ONLY()),
            cc(CoinComm::FOR_DESERIALIZATION_ONLY()),
            sig(CoinSig::FOR_DESERIALIZATION_ONLY()),
            pi(SplitProof::FOR_DESERIALIZATION_ONLY()) 
        {}
    public:
        void write(std::ostream&) const;
        void read(std::istream&);
        TxIn(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::TxIn&);
        friend std::istream& operator>>(std::istream&, libutt::TxIn&);
    };

    class TxOut {
    public:
        EPK epk;                    // the EPK of the recipient
        CoinComm cc_val;            // commitment to coin value transferred to the recipient

        KeyPrivateCtxt ctxt;    // encryption of coin value and coin commitment randomness
        // TODO: find a name for (r, g_1^r); it's getting confusing
        G1 epk_dh;              // g_1^r used to derive the H(g_1^{r \cdot ltsk.s}) DH shared key

        RangeProof range_pi;    // range proof for the coin value in 'cc'

        std::unique_ptr<CoinComm> cc;    // once TXN is processed, combine epk and cc_val into cc
        std::unique_ptr<CoinSig> sig;    // once TXN is processed, signature by the servers on the coin commitment 'cc'
    
    public:
        TxOut(const EPK& epk, const CoinComm& cc_val, const KeyPrivateCtxt& ctxt, const G1& epk_dh, const RangeProof& range_pi)
            : epk(epk), cc_val(cc_val), ctxt(ctxt), epk_dh(epk_dh), range_pi(range_pi)
        {}

    public:
        bool hasCoinSig() const { return sig != nullptr; }
        /**
         * Returns a SHA256 hash of this TxOut
         *  FIXME(Crypto): Need to ensure proper use of hash functions throughout the code to avoid surprising collisions due to formatting of input.
         */
        std::string hash() const;

        /**
         * Returns a SHA256 hash of all TxOuts in a TXN.
         */
        static std::string hashAll(const std::vector<TxOut>& txouts);

        /**
         * Attempts to decrypt the denomination, EPK randomizer and commitment randomness from the coin's ciphertext.
         * Returns the denom. and randomness if it succeeds.
         */
        std::optional<CoinSecrets> isMine(const Params& p, const LTSK& ltsk) const;

        /**
         * Returns the coin and re-randomizes the coin commitment and signature.
         * In the process, checks the bank's signature on the coin.
         */
        std::tuple<CoinSecrets, CoinComm, CoinSig> makeMine(const Params& p, const CoinSecrets& secrets, const BankPK& bpk) const;

        // Serialization and Deserialization techniques
        protected:
            TxOut(): 
                epk(EPK::FOR_DESERIALIZATION_ONLY()),
                cc_val(CoinComm::FOR_DESERIALIZATION_ONLY()),
                ctxt(KeyPrivateCtxt::FOR_DESERIALIZATION_ONLY()),
                range_pi(RangeProof::FOR_DESERIALIZATION_ONLY()) 
                {}
        public:
            void write(std::ostream&) const;
            void read(std::istream&);
            TxOut(std::istream&);
            friend std::ostream& operator<<(std::ostream&, const libutt::TxOut&);
            friend std::istream& operator>>(std::istream&, libutt::TxOut&); 
    };

    class Tx {
    public:
        std::vector<TxIn> ins;
        std::vector<TxOut> outs;

    public:
        Tx(std::vector<TxIn>&& ins, std::vector<TxOut>&& outs)
            : ins(std::move(ins)), outs(std::move(outs))
        {}

    public:
        /**
         * Splits the given (vector of) coins to the specified (vector of) LTPKs and amounts.
         * TODO: the coin tuple should just be a WalletCoin object, which is what a user would actually store in their wallet
         */
        static Tx create(const Params& p, const std::vector<std::tuple<CoinSecrets, CoinComm, CoinSig>>& c, const std::vector<std::tuple<LTPK, Fr>>& recv);

    public:
        bool verify(const Params& p, const BankPK& bpk) const;
        
        /**
         * If the TXN 'verifies', then 'process' it by signing the coin commitments in the TxOut's
         */
        void process(const Params& p, const BankSK& sk);

    // Serialization and Deserialization techniques
    protected:
        Tx() {}
    public:
        void write(std::ostream&) const;
        void read(std::istream&);
        Tx(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::Tx&);
        friend std::istream& operator>>(std::istream&, libutt::Tx&);
    };
}