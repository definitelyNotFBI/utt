#pragma once

#include <array>
#include <cstdlib>
#include <optional>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>

#include <utt/PolyCrypto.h>
#include <utt/Params.h>

#include <xassert/XAssert.h>
#include <xutils/Log.h>

namespace libutt {

    class CoinComm;
    class EPK;
    class KeyPrivateCtxt;
    class LTSK;

    /**
     * Each user has a long-term public key (LTPK).
     * Alice needs Bob's LTPK when paying him.
     */
    class LTPK {
    public:
        // signature verification keys
        G1 gr1;  // i.e., g_1^s
        G2 gr2;  // i.e., \tilde{g}_1^s; we need this for the G2 counterpart of the coin commitment 

        G2 pok;  // i.e., h_1^s; we need this as a proof of knowledge of the LTPK (and later on for the EPK)

    public:
        // encryption public key
        G1 e;

    public:
        //LTPK(const G1& gr1, const G2& gr2, const G1& e) 
        //    : gr1(gr1), gr2(gr2), e(e)
        //{}

        LTPK(const Params&p, const LTSK& ltsk);

    public:
        G1 signPk1() const { return gr1; }
        G2 signPk2() const { return gr2; }

        /**
         * Derives an EPK from the user's LTPK with the specified randomness r.
         * i.e., computes a Diffie-Hellman shared key z = H(gr1^r) and returns gr1 * g_1^z
         */
        EPK deriveEPK(const Params& p, const Fr& r, bool withG2 = true) const;

        /**
         * Returns a key-private encryption of the coin's value and commitment randomness.
         * Only this user can decrypt the return ciphertext (i.e., secrecy) and nobody can tell the ciphertext is for this user (i.e., anonymity).
         */
        KeyPrivateCtxt encrypt(const Params& p, const Fr& coinValue, const Fr& pedRand) const;
    };

    class ESK;

    class LTSK {
    public:
        // Secret key used to derive ESKs via Monero stealth addresses
        Fr s;
        
        // Encryption key used for Diffie-Hellman key exchange + AES
        Fr e;

    public:
        static LTSK random()
        {
            LTSK ltsk;
            ltsk.s = Fr::random_element();
            ltsk.e = Fr::random_element();
            return ltsk;
        }

    public:
        LTPK toLTPK(const Params& p) const {
            return LTPK(p, *this);
        }

        ESK deriveESK(const Params& p, const G1& R) const;
    };

    /**
     * Ephemeral public key (or a public identifier / serial number of a coin).
     * Note: needs to be committed in PS16 signature => needs Pedersen bases be the same as in PS16
     */
    class EPK {
    public:
        G1 v1;  // g_1^{s+z}, where z = H((g_1^s)^r) for random r

        std::optional<G2> v2;  // g_2^{s+z}, needed for \Gr_2 commitments to EPKs

        G2 pok; // h_1^{s+z}, needed for proving an EPK commitment g_1^{s+z} g^r is well-formed

    public:
        //EPK(const G1& v1) : v1(v1) {}
        //EPK(const G1& v1, const G2 v2) : v1(v1), v2(v2) {}

        EPK(const Params& p, const Fr& s)
            : v1(s * p.pedEskBase1()),
              v2(s * p.pedEskBase2()),
              pok(s * p.pokEskBase2())
        {}

        // WARNING: Needs to access ESK::s, so cannot have definition here due to forward declaration of ESK.
        EPK(const Params& p, const ESK& esk);

        /**
         * Creates an EPK from the specified LTPK using the Diffie-Hellman secret z
         */
        EPK(const Params&p, const LTPK& ltpk, const Fr& z, bool withG2)
        {
            v1 = ltpk.gr1 + z * p.pedEskBase1();
            pok = ltpk.pok + z * p.pokEskBase2();

            if(withG2)
                v2 = ltpk.gr2 + z * p.pedEskBase2();
        }

    public:

        bool hasG2() const { return v2.has_value(); }

        G1 asG1() const { return v1; }
        G2 asG2() const { testAssertTrue(hasG2()); return v2.value(); }

        // WARNING: Not for serializing EPKs b.c. does not output G2 counterparts
        std::string toString() const;

    // Serialization and Deserialization techniques
    protected:
        EPK() {}
    public:
        static EPK FOR_DESERIALIZATION_ONLY() { return EPK(); }
        void write(std::ostream&) const;
        void read(std::istream&);
        EPK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::EPK&);
        friend std::istream& operator>>(std::istream&, libutt::EPK&);
    };
    
    /**
     * Ephemeral secret key used to spend a coin
     */
    class ESK {
    public:
        Fr s;   // LTSK secret key + Diffie-Hellman secret key

    public:
        static ESK random() {
            ESK esk;
            esk.s = Fr::random_element();
            return esk;
        }
        ESK(Fr s) { this->s = s; }

    public:
        EPK toEPK(const Params& p) const {
            return EPK(p, s);
        }

    // Serialization and Deserialization techniques
    protected:
        ESK() {}
    public:
        void write(std::ostream&) const;
        void read(std::istream&);
        ESK(std::istream&);
        friend std::ostream& operator<<(std::ostream&, const libutt::ESK&);
        friend std::istream& operator>>(std::istream&, libutt::ESK&);
    };

    /**
     * Proof that an EPK is of the form g_1^{esk} g_2^v g^0 for v != 0.
     */
    class EpkProof {
    public:
        static bool verify(const Params& p, const EPK& epk);
    };
}