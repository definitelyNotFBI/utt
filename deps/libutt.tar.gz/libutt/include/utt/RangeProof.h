#pragma once

#include <array>
#include <cstdlib>
#include <optional>
#include <random>
#include <tuple>

#include <libff/algebra/scalar_multiplication/multiexp.hpp>

#include <utt/PolyCrypto.h>
#include <utt/Params.h>

#include <xassert/XAssert.h>
#include <xutils/AutoBuf.h>
#include <xutils/Log.h>
#include <xutils/NotImplementedException.h>

namespace libutt {

    class CoinComm;

    /**
     * A range proof for the TxOut commitment
     */
    class RangeProof {
    public:
        constexpr static size_t MAX_BITS = 64;

        static std::vector<G1> crs;
        static std::vector<Fr> g, q;
        static G2 h;
        static bool initialized;

    public:
        static bool __init_vectors();

    public:
        /**
         * Computes a range proof for g_2^val g^r.
         */
        RangeProof(const Params& p, const Fr& val, const Fr& r);

    public:
        /**
         * Verifies this range proof against the specified value commitment.
         */
        bool verify(const CoinComm& valComm) const;

        std::string hash() const {
            // TODO: compute
            return "deadbeef";
        }

    public:
        static std::vector<Fr> correlatedRandomness(const std::vector<Fr>& z);

    // Add serialization/deserailization
    protected:
        RangeProof() {}
    public:
        static RangeProof FOR_DESERIALIZATION_ONLY() { return RangeProof(); }
        void write(std::ostream& out) const;
        void read(std::istream& in);
        RangeProof(std::istream& in);
        friend std::ostream& operator<<(std::ostream& out, const libutt::RangeProof& p);
        friend std::istream& operator>>(std::istream& in, libutt::RangeProof& p);
    };

}