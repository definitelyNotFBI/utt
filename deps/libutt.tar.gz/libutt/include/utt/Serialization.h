#pragma once

#include <ostream>

namespace libutt {
using namespace std;

template <class T>
class Serializable {
public:
    virtual void write(std::ostream&) const = 0;
    virtual void read(std::istream&) = 0;
    friend std::ostream& operator<<(std::ostream&, const T&val);
    friend std::istream& operator>>(std::istream&, T&val);

    ~Serializable<T>() {}
};

template<class T>
std::ostream& OStream(std::ostream& out, const T&val) {
    val.write(out);
    return out;
}

}